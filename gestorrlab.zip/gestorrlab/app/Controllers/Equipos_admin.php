<?php 
namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\EquiposAdModel;
class Equipos_admin extends Controller{
    public function equipos_admi(){
        $user=new EquiposAdModel();
        $datos['equipos']=$user->orderBy('idequipo','ASC')->findAll();
        return view('tabla_equipos_admi',$datos);
    }
    public function borrarEqui($id=null){
        $user = new EquiposAdModel();
        $user->where('idequipo',$id)->delete();
        return $this->response->redirect(site_url('/equipos'));
    }
    public function in_equipo(){
        return view('insertar_equipo');
    }
    public function nuevoEquipo(){
        $user = new EquiposAdModel();
        $datos=
        
          [ 'idequipo'=>$this->request->getVar('id'),
            'nombre_equipo'=>$this->request->getVar('nomb'),
            'marca_equipo'=>$this->request->getVar('mar'),
            'modelo_equipo'=>$this->request->getVar('mod'),
            'descripcion_equipo'=>$this->request->getVar('desc'),
            'laboratorio_idlaboratorio'=>$this->request->getVar('lab'),
            'estado_equipo'=>$this->request->getVar('edo'),
            'fecha_registro_equipo'=>$this->request->getVar('fecha')];
            $user->insert($datos);
            return $this->response->redirect(site_url('/equipos'));
    }
    public function pedirEqui(){
        $user=new EquiposAdModel();
        $datos['equipos']=$user->orderBy('idequipo','ASC')->findAll();
        return view('pedirEquipo',$datos);
    }


    public function editar($id=null){
        $user = new EquiposAdModel();
        $datos['datitos']=$user->where('idequipo',$id)->first();
        return view('modificar_equipo',$datos);
    }
    public function actualizar($id=null){
        $user = new EquiposAdModel();
        $datos=[
            
            'idequipo'=>$this->request->getVar('id'),
            'nombre_equipo'=>$this->request->getVar('nomb'),
            'marca_equipo'=>$this->request->getVar('mar'),
            'modelo_equipo'=>$this->request->getVar('mod'),
            'descripcion_equipo'=>$this->request->getVar('desc'),
            'laboratorio_idlaboratorio'=>$this->request->getVar('lab'),
            'estado_equipo'=>$this->request->getVar('edo'),
            'fecha_registro_equipo'=>$this->request->getVar('fecha')
        ];
            $id=$this->request->getVar('id');
            $user->update($id,$datos);
            return $this->response->redirect(site_url('/equipos'));
    }
    public function prestamo($id = null, $idlab = null)
    {
     //$user = new UsuarioModel();
     //$datos['datitos'] = $user->orderBy('idusuario', 'ASC')->findAll();
     
       $user = new EquiposAdModel();
        $datos['equipos'] = $user->where('idequipo', $id)->where('laboratorio_idlaboratorio', $idlab)->first();
        return view('prestamo', $datos);
    }
}

