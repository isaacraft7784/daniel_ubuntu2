<?php
namespace App\Controllers;

use CodeIgniter\Controller;

class vistascontroller extends Controller 
{
    public function iniciar(){
        return view('inicio_sesion');

    }
    public function inicio(){
        return view('inicio');

    }
    public function inicioAd(){
        return view('inicio_admin');

    }
    public function terminos(){
        return view('terminos');

    }
}

?>