<?php 
namespace App\Controllers;

use CodeIgniter\Controller;

class Form_capacitacion extends Controller{
    public function formulario_caps()
    { 
        return view('form_capacitaciones');
    }

}