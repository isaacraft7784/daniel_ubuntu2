<?php 
namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\UsuarioModel;
class Usuario extends Controller{
    public function usuarios_admi(){
        $user= new UsuarioModel();
        $datos['datitos']=$user->orderBy('matrcula_usuario','ASC')->findAll();
        return view('tabla_usuarios_admi',$datos);
    }
    public function borrar($id=null){
        $user = new UsuarioModel();
        $user->where('idusuario',$id)->delete();
        return $this->response->redirect(site_url('/usuarios_admi'));
    }

    public function alta_usuarios(){
        return view('cuerpos/alta_usuarios');
    }
    public function nuevoUsuario(){
        $user = new UsuarioModel();
        $datos=
        
          [ 'idusuario'=>$this->request->getVar('id'),
            'matrcula_usuario'=>$this->request->getVar('mat'),
            'nombre_usuario'=>$this->request->getVar('nom'),
            'apellido_paterno'=>$this->request->getVar('apep'),
            'apellido_materno'=>$this->request->getVar('apem'),
            'password_usuario'=>password_hash($this->request->getVar('pass'),PASSWORD_DEFAULT),
            'correo_usuario'=>$this->request->getVar('email'),
            'telefono_usuario'=>$this->request->getVar('tel'),
            'numero_seguro_social'=>$this->request->getVar('NSS'),
            'carrera_idcarrera'=>$this->request->getVar('carrera'),
            'rol_usuario'=>$this->request->getVar('rol'),
            'estado_usuario'=>$this->request->getVar('edo'),
            'fecha_creacion_usuario'=>$this->request->getVar('fecha')];
            $user->insert($datos);
            return view('inicio_sesion');
        
    }
    public function editar($id=null){
        $user = new UsuarioModel();
        $datos['datitos']=$user->where('idusuario',$id)->first();
        return view('modificar_usuario',$datos);
    }
    public function actualizaar ($id=null){
        $user = new UsuarioModel();
        $datos=[
            'matrcula_usuario'=>$this->request->getVar('mat'),
            'nombre_usuario'=>$this->request->getVar('nom'),
            'apellido_paterno'=>$this->request->getVar('apep'),
            'apellido_materno'=>$this->request->getVar('apem'),
            'password_usuario' => $this->request->getVar('pass'),
            'correo_usuario'=>$this->request->getVar('email'),
            'telefono_usuario'=>$this->request->getVar('tel'),
            'numero_seguro_social'=>$this->request->getVar('NSS'),
            'rol_usuario'=>$this->request->getVar('rol'),
            'carrera_idcarrera'=>$this->request->getVar('carrera'),
            'fecha_creacion_usuario' => $this->request->getVar('fecha')
        ];
       
        $id=$this->request->getVar('id');
        $user->update($id,$datos);

        return $this->response->redirect(site_url('/usuarios_admi'));
    }
}
?>