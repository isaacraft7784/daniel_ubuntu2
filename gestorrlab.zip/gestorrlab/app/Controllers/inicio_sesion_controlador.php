<?php
namespace App\Controllers;
 

use App\Models\sesion;
use App\Models\UsuarioModel;

class inicio_sesion_controlador extends BaseController {
    
    public function iniciar_ses()
    {
   $session = session();
        $userModel = new sesion();
        
        $email = $this->request->getVar('user');
        $password = $this->request->getVar('contra');
        
        $data = $userModel->where('correo_usuario', $email)->first();
        
        if($data){
            $pass = $data['password_usuario'];
          password_verify($password, $pass);
            
            if(password_verify($password, $pass)||$password==$pass){
                session_start();
                $ses_data = [
                    'id' => $data['idusuario'],
                    'name' => $data['nombre_usuario'],
                    'email' => $data['correo_usuario'],
                    'isLoggedIn' => TRUE
                ];
                $session->set($ses_data);
                return redirect()->to('inicio');
                var_dump($session);
            
            }else{
              echo $pass,$password;
              echo"contraseña no";
                $session->setFlashdata('msg', 'Password is incorrect.');
               // return redirect()->to('inico');
            }
        }else{
          echo"correo no";
            $session->setFlashdata('msg', 'Email does not exist.');
           // return redirect()->to('inicio');
        }
    }
    public function cerrar_ses(){
     $ses_data['isLoggedIn']=false;
       return redirect()->to('inicio_sesion'); 
    }
}
?>