<?php 
namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\PrestamoModel;
class Prestamo extends Controller{
   public function index(){
    return view("prestamo");
   }
   public function prest_admi(){
      $user = new PrestamoModel();
      $datos['prest']=$user->orderBy('idprestamo','ASC')->findAll();
      return view('tabla_prestamo_admi',$datos);
  }
  public function nuevoPrestamo(){
   $user = new PrestamoModel();
   $datos=
   
     [ 'idprestamo'=>$this->request->getVar('id'),
       'prestamo_fecha'=>$this->request->getVar('fp'),
       'hora_inicio'=>$this->request->getVar('hi'),
       'hora_final'=>$this->request->getVar('hf'),
       'prestamo_observaciones'=>$this->request->getVar('obs'),
       'equipo_idequipo2'=>$this->request->getVar('equi'),
       'usuario_idusuario'=>$this->request->getVar('usuario'),
       'laboratorio_idlaboratorio3'=>$this->request->getVar('lab'),
       'estado_prestamo'=>$this->request->getVar('edo'),
       'fecha_registro_prestamo'=>$this->request->getVar('fecha'),
      ];
       
       $user->insert($datos);
       return redirect()->to(base_url('solicitar')); // Modificación en esta línea
   }
   public function nuevoPrestamoLab(){
      $user = new PrestamoModel();
      $datos=
      
        [ 'idprestamo'=>$this->request->getVar('id'),
          'prestamo_fecha'=>$this->request->getVar('fp'),
          'hora_inicio'=>$this->request->getVar('hi'),
          'hora_final'=>$this->request->getVar('hf'),
          'prestamo_observaciones'=>$this->request->getVar('obs'),
          'equipo_idequipo2'=>$this->request->getVar('equi'),
          'usuario_idusuario'=>$this->request->getVar('usuario'),
          'laboratorio_idlaboratorio3'=>$this->request->getVar('lab'),
          'estado_prestamo'=>$this->request->getVar('edo'),
          'fecha_registro_prestamo'=>$this->request->getVar('fecha'),
         ];
          
          $user->insert($datos);
          return redirect()->to(base_url('pedirLab')); // Modificación en esta línea
      }
      public function borrarpres($id=null){
        $user = new PrestamoModel();
        $user->where('idprestamo',$id)->delete();
        return $this->response->redirect(site_url('/prest_admi'));
    }
  
}
?>