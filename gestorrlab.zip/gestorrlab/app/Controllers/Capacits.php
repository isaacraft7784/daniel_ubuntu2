<?php 
namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\CapModel;
class Capacits extends Controller{
    public function caps(){
        $user= new CapModel();
        $datos['capaci']=$user->orderBy('idcapacitacion','ASC')->findAll();
        return view('tabla_caps_admi',$datos);
    }
    public function in_cap(){
        return view('insertar_cap');
    }
    public function nuevoCap(){
        $user = new CapModel();
        $id= $this->request->getVar('id');
        $nom = $this->request->getVar('nomb');
        $dur =$this->request->getVar('dur');
        $desc=$this->request->getVar('desc');
        $inst=$this->request->getVar('inst');
        $clave=$this->request->getVar('clave');
        $edo=$this->request->getVar('edo');
        $fecha=$this->request->getVar('fecha');
        $datos=
        
          [ 'idcapacitacion'=>$id,
            'nombre_capacitacion'=>$nom,
            'duracion_capacitacion'=>$dur,
            'descrpcion_capacitacion'=>$desc,
            'nombre_instructor'=>$inst,
            'clave_capacitacion'=>$clave,
            'estado_capacitacion'=>$edo,
            'fecha_registro_capacitacion'=>$fecha];
            $user->insert($datos);
            return $this->response->redirect(site_url('/caps_admi'));
            
    }
    public function pedirCap(){
        $user= new CapModel();
        $datos['capaci']=$user->orderBy('idcapacitacion','ASC')->findAll();
        return view('pedirCapacitacion',$datos);
    }
    public function borrarCap($id=null){
        $user = new CapModel();
        $user->where('idcapacitacion',$id)->delete();
        return $this->response->redirect(site_url('/caps_admi'));
    }
    public function modificarcap($id=null){
        $user = new CapModel();
        $datos['datitos']=$user->where('idcapacitacion',$id)->first();
        return view('modificar_capacitacion',$datos);
    }
    public function actualizarca($id=null){
        $user = new CapModel();
        $datos=[
            
            'idcapacitacion'=>$this->request->getVar('id'),
            'nombre_capacitacion'=>$this->request->getVar('nomb'),
            'duracion_capacitacion'=>$this->request->getVar('dur'),
            'descripcion_capacitacion'=>$this->request->getVar('desc'),
            'nombre_instructor'=>$this->request->getVar('inst'),
            'clave_capacitacion'=>$this->request->getVar('clave'),
            'estado_capacitacion'=>$this->request->getVar('edo'),
            'fecha_registro_capacitacion'=>$this->request->getVar('fecha')
        ];
            $id=$this->request->getVar('id');
            $user->update($id,$datos);
            return $this->response->redirect(site_url('/caps_admi'));
    }
    public function form_capacitacion($id=null){
        $user = new CapModel();
        $datos['capaci']=$user->where('idcapacitacion',$id)->first();
        return view('form_capacitaciones',$datos);
    
    }
    
}
?>