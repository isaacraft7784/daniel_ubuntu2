<?php 
namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\LaboratorioModel;
class Labs extends Controller{
    public function in_lab(){
        return view('insertar_lab');
    }
    public function nuevoLab(){
        $user = new LaboratorioModel();
        $datos=
        
          [ 'idlaboratorio'=>$this->request->getVar('id'),
            'nombre_laboratorio'=>$this->request->getVar('nomb'),
            'ubicacion_laboratorio'=>$this->request->getVar('ubi'),
            'nombre_responsable_laboratorio'=>$this->request->getVar('resp'),
            'nombre_edificio'=>$this->request->getVar('edif'),
            'numero_piso'=>$this->request->getVar('piso'),
            'estado_laboratorio'=>$this->request->getVar('edo'),
            'fecha_registro_laboratorio'=>$this->request->getVar('fecha')];
            $user->insert($datos);
            return $this->response->redirect(site_url('labs_admin'));
            
    }
    public function pedir(){
        $user=new LaboratorioModel();
        $datos['labs']=$user->orderBy('idlaboratorio','ASC')->findAll();
        return view('pedirLab',$datos);
    }
    public function prestamo($id = null)
    {
     //$user = new UsuarioModel();
     //$datos['datitos'] = $user->orderBy('idusuario', 'ASC')->findAll();
     
       $user = new LaboratorioModel();
        $datos['labs'] = $user->where('idlaboratorio', $id)->first();
        return view('prestamo_lab', $datos);
    }
    public function labs_admin(){
        $user=new LaboratorioModel();
        $datos['labos']=$user->orderBy('idlaboratorio','ASC')->findAll();
        return view('tabla_labs_admi',$datos);
    }
    public function borrarlabo($id=null){
        $user = new LaboratorioModel();
        $user->where('idlaboratorio',$id)->delete();
        return $this->response->redirect(site_url('labs_admin'));
    }
    public function editarlabo($id=null){
        $user = new LaboratorioModel();
        $datos['datitos']=$user->where('idlaboratorio',$id)->first();
        return view('modificar_laboratorio',$datos);
    }
    public function actualizar($id=null){
        $user = new LaboratorioModel();
        $datos=[
            
            'idlaboratorio'=>$this->request->getVar('id'),
            'nombre_laboratorio'=>$this->request->getVar('nomb'),
            'ubicacion_laboratorio'=>$this->request->getVar('ubi'),
            'nombre_responsable_laboratorio'=>$this->request->getVar('resp'),
            'nombre_edificio'=>$this->request->getVar('edif'),
            'numero_piso'=>$this->request->getVar('piso'),
            'estado_laboratorio'=>$this->request->getVar('edo'),
            'fecha_registro_laboratorio'=>$this->request->getVar('fecha')
        ];
            $id=$this->request->getVar('id');
            $user->update($id,$datos);
            return $this->response->redirect(site_url('labs_admin'));
    }
}
?>