<?php
//controlador
namespace App\Controllers;
use CodeIgniter\Controller; //Tener más de un controlador
use App\Models\GestortModelo;//llama a nuestro modelo

class Home extends BaseController
{
    /*public function __construct()
    {
        $db = \Config\Database::connect();//conexión a la base de datos
        $this->data = $db->query("SELECT nombre FROM carrera");//consulta
        $this->gm=new GestorModelo();//instancia
    }*/
    public function index()
    {
        return view('form_email');

    }
    public function enviar_email(){
        $asunto = $this->request->getPost('asunto');
        $mensaje = $this->request->getPost('mensaje');
        $correo = $this->request->getPost('correo');

        $email = \Config\Services::email();

        $email->setFrom('nahomi.montieldelos@alumno.buap.mx', 'Administrador');
        $email->setTo($correo);


        $email->setSubject($asunto);
        $email->setMessage($mensaje);

        $email->send();
        return view('form_email');
 
       
    }
}
