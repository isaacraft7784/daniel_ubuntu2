<?php 
namespace App\Controllers;

use CodeIgniter\Controller;

class Usuarios_admi extends Controller{
    public function usuarios_admi(){
        $user= new UsuarioModel();
        $datos['datitos']=$user->orderBy('matrcula_usuario','ASC')->findAll();
        return view('usuarios',$datos);
    }
    public function borrar($id=null){
        $user = new UsuarioModel();
        $user->where('idusuario',$id)->delete();
        return $this->response->redirect(site_url('/tabla_usuarios_admi'));
    }

}
?>