<?php 
namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\CapacitaModel;
class Insertar_capacitacion extends Controller{
    

    public function caps(){
        $user= new CapacitaModel();
        $datos['caps']=$user->orderBy('matrcula_usuario','ASC')->findAll();
        return view('tabla_caps_admi');
    }
    public function in_cap(){
        return view('insertar_cap');
    }
    public function nuevoCap(){
        $user = new CapacitaModel();
        $datos=
        
          [ 'idcapacitacion'=>$this->request->getVar('id'),
            'nombre_capacitacion'=>$this->request->getVar('nomb'),
            'duracion_capacitacion'=>$this->request->getVar('dur'),
            'descrpcion_capacitacion'=>$this->request->getVar('desc'),
            'nombre_instructor'=>$this->request->getVar('inst'),
            'clave_capacitacion'=>$this->request->getVar('clave'),
            'estado_capacitacion'=>$this->request->getVar('edo'),
            'fecha_registro_capacitacion'=>$this->request->getVar('fecha')];
            $user->insert($datos);
            
    }

}