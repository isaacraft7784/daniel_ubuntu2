<?php 
namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\UsuarioCapModel;
class Usuario_Capacitacion extends Controller{
    public function usuariocapi(){
        $user= new UsuariocapModel();
        $datos['capacitaciones']=$user->orderBy('idusuario_capacitacion','ASC')->findAll();
        return view('usuario_cap_admi',$datos);
    }
    public function nuevoCap(){
        $user = new UsuarioCapModel();
        $datos=
        
          [ 'idusuario_capacitacion'=>$this->request->getVar('id'),
            'fecha_inicio_capacitacion'=>$this->request->getVar('fecha_inicio'),
            'fecha_fin_capacitacion'=>$this->request->getVar('fecha_fin'),
            'usuario_idusuario2'=>$this->request->getVar('id_usuario'),
            'capacitacion_idcapacitacion2'=>$this->request->getVar('id_cap'),
          ];
            $user->insert($datos);
            return $this->response->redirect(site_url('/pedirCap'));
            
    }

}
?>