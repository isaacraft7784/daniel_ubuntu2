<?php

use App\Controllers\Usuario;
?>
<!DOCTYPE html>
<html>
<head>
<title>W3.CSS Template</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
html,body,h1,h2,h3,h4 {font-family:"Lato", sans-serif}
.mySlides {display:none}
.w3-tag, .fa {cursor:pointer}
.w3-tag {height:15px;width:15px;padding:0;margin-top:6px}
</style>




<style>
.shadow__btn {
  align-items: center;
          justify-content: center;
  padding: 10px 20px;
  border: none;
  font-size: 17px;
  color: #fff;
  border-radius: 7px;
  letter-spacing: 4px;
  font-weight: 700;
  text-transform: uppercase;
  transition: 0.5s;
  transition-property: box-shadow;
}

.shadow__btn {
  background: rgb(0,140,255);
  box-shadow: 0 0 25px rgb(0,140,255);
}

.shadow__btn:hover {
  box-shadow: 0 0 5px rgb(0,140,255),
              0 0 25px rgb(0,140,255),
              0 0 50px rgb(0,140,255),
              0 0 100px rgb(0,140,255);
}
</style>














</head>
<body>

<!-- Links (sit on top) -->
<div class="w3-top">
 <div class="w3-container w3-blue">
      <div class="w3-col s3">
      <a href="<?=base_url('usuarios_admi'); ?>" class="w3-button w3-block">Usuarios</a>
    </div>
    <div class="w3-col s3">
      <a href="<?= base_url('caps_admi')?>" class="w3-button w3-block">Capacitaciones</a>
    </div>
    <div class="w3-col s3">
      <a href="<?= base_url('labs_admin')?>" class="w3-button w3-block">Laboratorios</a>
    </div>
      <div class="w3-col s3">
      <a href="<?= base_url('equipos')?>" class="w3-button w3-block">Equipos</a>
    </div>
    <div class="w3-col s3">
      <a href="<?= base_url('inicio')?>" class="w3-button w3-indigo w3-block">Inicio</a>
    </div>
    <div class="w3-col s3">
      <a href="<?= base_url("usuario_cap_admi")?>" class="w3-button w3-indigo w3-block">Usuario Capacitaciones</a>
    </div>
     <div class="w3-col s3">
      <a href="<?= base_url('prest_admi')?>" class="w3-button w3-indigo w3-block">Prestamos</a>
       </div>
       <div class="w3-col s3">
      <a href="<?= base_url('cerrar')?>" class="w3-button w3-indigo w3-block">Cerrar sesión</a>
    </div>
    </div>
  </div>
</div>

<!-- Content -->
<div class="w3-content" style="max-width:1100px;margin-top:80px;margin-bottom:80px">

  <div class="w3-panel w3-center">
    <h1><b>Gestor de Laboratorios y Equipos</b></h1>
    <p>Complejo Regional Centro San Jose Chiapa</p>
  </div>

  <!-- Slideshow -->
  <div class="w3-container">
    <div class="w3-display-container mySlides">
       <video src="C:\Users\Isaac19\Desktop\images\video1.mp4"  style="width:100%" controls>
      <div class="w3-display-topleft w3-container w3-padding-32">
        <span class="w3-white w3-padding-large w3-animate-bottom">Video Institucional</span>
      </div>
    </div>
    <div class="w3-display-container mySlides">
      <img src="C:\Users\Isaac19\Desktop\images\Opera Instantánea_2023-05-23_180756_www.elciudadano.com.png" style="width:100%">
      <div class="w3-display-middle w3-container w3-padding-32">
        <span class="w3-white w3-padding-large w3-animate-bottom">Edificio JChiapa 2</span>
      </div>
    </div>
    <div class="w3-display-container mySlides">
       <img src="C:\Users\Isaac19\Desktop\images\BUAPSANJOSÉ2.jpg" style="width:100%">
      <div class="w3-display-topright w3-container w3-padding-32">
        
        <span class="w3-white w3-padding-large w3-animate-bottom">Edificio JChiapa 1</span>
      </div>
    </div>

    <!-- Slideshow next/previous buttons -->
    <div class="w3-container w3-blue w3-padding w3-xlarge">
      <div class="w3-left" onclick="plusDivs(-1)"><i class="fa fa-arrow-cirlce-left w3-hover-text-teal"></i></div>
      <div class="w3-right" onclick="plusDivs(1)"><i class="fa fa-arrow-circle-right w3-hover-text-teal"></i></div>
    
      <div class="w3-center">
        <span class="w3-tag demodots w3-border w3-transparent w3-hover-white" onclick="currentDiv(1)"></span>
        <span class="w3-tag demodots w3-border w3-transparent w3-hover-white" onclick="currentDiv(2)"></span>
        <span class="w3-tag demodots w3-border w3-transparent w3-hover-white" onclick="currentDiv(3)"></span>
      </div>
    </div>
  </div>
  
  <!-- Grid -->
  <div class="w3-row w3-container">
    <div class="w3-center w3-padding-64">
      <span class="w3-xlarge w3-bottombar w3-border-blue w3-padding-16">¿Qué ofrecemos?</span>
      <br>  <br>
       <span class="w3-xlarge w3-center  w3-bottombar  "><b>Ponemos a tu disposición un Gestor exclusivo que te brinda la posibilidad de llevar a cabo una amplia gama de acciones, destacando entre ellas:</b></span>
    </div>
    <div class="w3-col l3 m6 w3-cyan w3-container w3-padding-16">
      <h3>Ingresar Capacitacion</h3>
      <p>Podrás tener el control del registro de capacitaciones, así como poder eliminarlos, editarlos y actualizarlos.</p>
    </div>

    <div class="w3-col l3 m6 w3-light-blue w3-container w3-padding-16">
      <h3>Ingresar Usuarios</h3>
      <p>Podrás tener el control del registro de usuarios, así como poder eliminarlos, editarlos y actualizarlos.</p>
    </div>

    <div class="w3-col l3 m6 w3-blue w3-container w3-padding-16">
      <h3>Ingresar Laboratorios</h3>
      <p>Podrás tener el control del registro de laboratorios, así como poder eliminarlos, editarlos y actualizarlos.</p>
    </div>

    <div class="w3-col l3 m6 w3-indigo w3-container w3-padding-16">
      <h3>Ingresar Equipos</h3>
      <p>Podrás tener el control del registro de laboratorios, así como poder eliminarlos, editarlos y actualizarlos.</p>
    </div>
  </div>

  

  <!-- Grid -->
  <div class="w3-row-padding" id="about">
    <div class="w3-center w3-padding-64">
      <span class="w3-xlarge w3-bottombar w3-border-dark-grey w3-padding-16">¿Quienes somos?</span>
      <br>   
      <br>  
        <span class="w3-container w3-bottombar  "><b>Nosotros somos "ELMO" una entidad distinguida que se define por nuestra excelencia y dedicación en cada uno de los ámbitos en los que nos desenvolvemos. Nuestra identidad se forja a través de un equipo altamente capacitado y comprometido, cuya misión principal radica en satisfacer las necesidades más exigentes de nuestros apreciados compañeros. En nuestro afán por alcanzar la perfección, nos esforzamos constantemente por superar las expectativas y brindar un servicio excepcional, guiados por valores como la integridad, la innovación y el respeto. Como referente en nuestro campo, nos enorgullece ofrecer soluciones personalizadas y de calidad que perduran en el tiempo, consolidando así nuestra reputación como líderes indiscutibles.</b></span>

    </div>




    <div class="w3-third w3-margin-bottom">
      <div class="w3-card-4">

        <div class="w3-container">
          <h3>Isaac Vidal Rivera Vega</h3>
          <p class="w3-opacity">Desarollador</p>
    
        </div>
      </div>
    </div>

    <div class="w3-third w3-margin-bottom">
      <div class="w3-card-4">
   
        <div class="w3-container">
          <h3>Juan Daniel Carrasco Alonso</h3>
          <p class="w3-opacity">Desarollador</p>
 
        </div>
      </div>
    </div>

    <div class="w3-third w3-margin-bottom">
      <div class="w3-card-4">
 
        <div class="w3-container">
          <h3>Yael Josefath Ramos Santiago</h3>
          <p class="w3-opacity">Desarollador</p>
         
        </div>
      </div>
    </div>
  </div>


   <div class="w3-third w3-margin-bottom">
      <div class="w3-card-4" >
       
        <div class="w3-container">
          <h3>Johan Naim Juárez Evangelista</h3>
          <p class="w3-opacity">Desarollador</p>
     
        </div>
      </div>
    </div>

    <div class="w3-third w3-margin-bottom">
      <div class="w3-card-4">
       
        <div class="w3-container">
          <h3>Nahomi Montiel de los Santos</h3>
          <p class="w3-opacity">Project Manager</p>
   
        </div>
      </div>
    </div>

   
  </div>



           <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br>

  <!-- Contact -->
  <div class="w3-center w3-padding-64" id="contact">
    <span class="w3-xlarge w3-bottombar w3-border-dark-grey w3-padding-16">Contáctanos</span>
  </div>

  <form class="w3-container" action="/action_page.php" target="_blank">
    <div class="w3-section">
      <label>Nombre</label>
      <input class="w3-input w3-border w3-hover-border-black" style="width:100%;" type="text" name="Name" required>
    </div>
    <div class="w3-section">
      <label>Email</label>
      <input class="w3-input w3-border w3-hover-border-black" style="width:100%;" type="text" name="Email" required>
    </div>
    <div class="w3-section">
      <label>Asunto</label>
      <input class="w3-input w3-border w3-hover-border-black" style="width:100%;" name="Subject" required>
    </div>
    <div class="w3-section">
      <label>Mensaje</label>
      <input class="w3-input w3-border w3-hover-border-black" style="width:100%;" name="Message" required>

    </div>

 <button class="shadow__btn"> Enviar </button>  
      <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br>
</form>
</div>

<!-- Footer -->

<footer class="w3-container w3-padding-32 w3-indigo w3-center" id="piepagina">
  <h4>Benemérita Universidad Autónoma de Puebla</h4>
  <h5>4 Sur 104 Centro Histórico C.P. 72000</h5>
  <h5>Teléfono +52 (222) 229 55 00</h5>
  <a href="<?= base_url('terminos')?>" class="w3-button w3-white w3-margin"><i class=" w3-center  "></i>Terminos y Condiciones</a>
 
 
  <div class="w3-xlarge w3-section">
    <a href="https://www.facebook.com/BUAPoficial"><i class="fa fa-facebook-official w3-hover-opacity"></a></i>
     <a href="https://www.instagram.com/buapoficial/"><i class="fa fa-instagram w3-hover-opacity"></a></i>
      <a href="https://twitter.com/buapoficial"><i class="fa fa-twitter w3-hover-opacity"></a></i>
       <a href="https://www.youtube.com/user/ibuap"><i class="fa fa-youtube w3-hover-opacity"></a></i>
       
  </div>
  <p>Realizado por el equipo ELMO <a href="https://www.w3schools.com/w3css/default.asp" title="W3.CSS" target="_blank" class="w3-hover-text-green">w3.css</a></p>
</footer>


<script>
// Slideshow
var slideIndex = 1;
showDivs(slideIndex);

function plusDivs(n) {
  showDivs(slideIndex += n);
}

function currentDiv(n) {
  showDivs(slideIndex = n);
}

function showDivs(n) {
  var i;
  var x = document.getElementsByClassName("mySlides");
  var dots = document.getElementsByClassName("demodots");
  if (n > x.length) {slideIndex = 1}    
  if (n < 1) {slideIndex = x.length} ;
  for (i = 0; i < x.length; i++) {
    x[i].style.display = "none";  
  }
  for (i = 0; i < dots.length; i++) {
    dots[i].className = dots[i].className.replace(" w3-white", "");
  }
  x[slideIndex-1].style.display = "block";  
  dots[slideIndex-1].className += " w3-white";
}
</script>

</body>
</html>
