<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Politicas</title>
</head>
<body>
    <div class="w3-container w3-bottombar">
<h2>Políticas de privacidad
Queremos informarte del tipo de datos que recogemos cuando utilizas nuestros servicios.
Recogemos información para proporcionar los mejores servicios a todos nuestros usuarios, desde determinar información básica, hasta datos más complejos. El tipo de información que recoge nuestra página y cómo se utiliza esa información depende del uso que hagas de nuestros servicios, así como de la manera en la que administres los controles de privacidad.
Al crear una cuenta, nos proporcionas información personal que incluye tu nombre y una contraseña.
También usamos tu información para garantizar que nuestros servicios funcionan correctamente, por ejemplo, realizar un seguimiento de las interrupciones de red o solucionar los problemas de los que nos informas. Además, utilizamos tu información para mejorar nuestros servicios, por ejemplo, conocer los términos de búsqueda que se escriben mal con mayor frecuencia nos ayuda a mejorar las funciones de revisión ortográfica que se utilizan en todos nuestros servicios.
Términos y condiciones
Esta página web es propiedad y está operado por el equipo de desarrolladores Escuadrón Lobo Maravilla perteneciente al complejo regional San José Chiapa de la carrera de Ingeniería en Sistemas y Tecnologías de la Información Industrial (ISTII). 
Este documento establece los términos y condiciones bajo los cuales tú puedes usar nuestra página web y servicios ofrecidos por nosotros. 
Esta página web ofrece a los visitantes el poder reservar laboratorios y los equipos que se encuentran en el centro Regional San José Chiapa perteneciente a la BUAP con un fin exclusivamente educativo. Al acceder o usar la página web de nuestro servicio, usted aprueba que haya leído, entendido y aceptado estar sujeto a estos términos:
Para usar nuestra página web y / o recibir nuestros servicios, debes pertenecer al Complejo Regional San José Chiapa. No tienes permitido utilizar esta página web y / o recibir servicios si hacerlo está prohibido en tu país o en virtud de cualquier ley o regulación aplicable a tu caso.
Al prestarte un equipo, aceptas que: (i) eres responsable de leer el listado completo del equipo antes de comprometerte a reservarlo: (ii) celebras un contrato legalmente vinculante para reservar un equipo. (iii) Si alguno de los equipos resulta ser dañado durante tu tiempo de reservación tendrás que comunicarle al administrador responsable en la brevedad posible.
Sin aviso previo podemos cambiar los servicios, dejar de proporcionar los servicios o cualquier característica de este, como también crear límites, asimismo, podemos suspender de manera permanente o temporal el acceso a la página web sin previo aviso ni responsabilidad por cualquier motivo.}
</h2>
</div>
<a href="<?= base_url('inicio'); ?>" class="w3-button w3-block w3-blue">Inicio</a>
</body>
</html>