<!DOCTYPE html>
<html>
<title>Usuarios Admin</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Bebas Neue">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Nabla">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.css">
<body>

<style>
.w3-allerta {
  font-family: "Bebas Neue", Sans-serif;
}
</style>

<style>
.w3-allert {
  font-family: "Bebas Neue", Sans-serif;
}
</style>

<style>
.w3-nabla {
  font-family: "Heebo", Sans-serif;
}
</style>

<div class="w3-container w3-indigo w3-center w3-allerta">
  <p class="w3-xxxlarge">Capacitaciones</p>
</div>

<div class="w3-container  w3-center w3-nabla">
<h2><p class="w3-allert">Tabla de las capacitaciones</p></h2>
  <p>Administrador</p>

  <div class="w3-top">
  <div class="w3-row w3-padding w3-indigo">
    <div class="w3-col s3">
      <a href="<?= base_url('equipos'); ?>" class="w3-button w3-block w3-blue">EQUIPOS</a>
    </div>
    <div class="w3-col s3">
      <a href="<?= base_url('usuarios_admi'); ?>" class="w3-button w3-block w3-blue">USUARIOS</a>
    </div>
    <div class="w3-col s3">
      <a href="<?= base_url('in_cap'); ?>" class="w3-button w3-block w3-blue">NUEVA CAPACITACIÓN</a>
    </div>
    <div class="w3-col s3">
      <a href="<?= base_url('inicio_admin')?>" class="w3-button w3-block w3-blue">inicio</a>
    </div>
  </div>
</div>
  <div class="w3-container">

  <input class="w3-input w3-border w3-padding" type="text" placeholder="Buscar Usuario..." id="myInput" onkeyup="myFunction()">

  <table class="w3-table-all w3-margin-top" id="myTable">
    <tr class="w3-indigo">
      <th style="width:40%;">Id capacitación</th>
      <th style="width:40%;">Nombre</th>
      <th style="width:60%;">Duración</th>
      <th style="width:40%;">Descripción</th>
      <th style="width:40%;">Instructor</th>
      <th style="width:40%;">Clave</th>
      <th style="width:40%;">Estado</th>
      <th style="width:40%;">Fecha Registro</th>
      <th style="width:40%;">Eliminar</th>
      <th style="width:40%;">Modificar</th>
    </tr>
    <?php
       foreach ($capaci as $datos):
     ?>
    <tr>
      <td><?= $datos['idcapacitacion']; ?></td>
      <td><?= $datos['nombre_capacitacion']; ?></td>
      <td><?= $datos['duracion_capacitacion']; ?></td>
      <td><?= $datos['descripcion_capacitacion']; ?></td>
      <td><?= $datos['nombre_instructor']; ?></td>
      <td><?= $datos['clave_capacitacion']; ?></td>
      <td><?= $datos['estado_capacitacion']; ?></td> 
      <td><?= $datos['fecha_registro_capacitacion']; ?></td>  
      <td><a href="<?=base_url('borrarCap/'.$datos['idcapacitacion']);?>"><i class="fa-solid fa-trash-can"></i></a></td>
      <td><a href="<?=base_url('modificarcap/'.$datos['idcapacitacion']);?>"><i class="fa-solid fa-pencil"></i></a></td>   
    </tr>
    <?php endforeach; ?>
    
  </table>

</div>

<script>
function myFunction() {
  var input, filter, table, tr, td, i;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[0];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }
  }
}
</script>
  
</div>

</body>
</html>