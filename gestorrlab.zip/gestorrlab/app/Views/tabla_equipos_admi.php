<!DOCTYPE html>
<html>
<title>Equipos Admin</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Bebas Neue">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Nabla">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.css">
<body>

<style>
.w3-allerta {
  font-family: "Bebas Neue", Sans-serif;
}
</style>

<style>
.w3-allert {
  font-family: "Bebas Neue", Sans-serif;
}
</style>

<style>
.w3-nabla {
  font-family: "Heebo", Sans-serif;
}
</style>

<div class="w3-container w3-indigo w3-center w3-allerta">
  <p class="w3-xxxlarge">Equipos</p>
</div>

<div class="w3-container  w3-center w3-nabla">
<h2><p class="w3-allert">Tabla de los Equipos</p></h2>
  <p>Administrador</p>
  <div class="w3-col s3">
      <a href="<?= base_url('inicio_admin')?>" class="w3-button w3-block w3-blue">inicio</a>
    </div>
  <div class="w3-top">
  <div class="w3-row w3-padding w3-indigo">
    <div class="w3-col s3">
      <a href="<?= base_url('caps_admi'); ?>" class="w3-button w3-block w3-blue">CAPACITACIONES</a>
    </div>
    <div class="w3-col s3">
      <a href="<?= base_url('prest_admi'); ?>" class="w3-button w3-block w3-blue">PRESTAMOS</a>
    </div>
    <div class="w3-col s3">
      <a href="<?= base_url('usuarios_admi'); ?>" class="w3-button w3-block w3-blue">USUARIOS</a>
    </div>
    <div class="w3-col s3">
      <a href="<?= base_url('in_equipo'); ?>" class="w3-button w3-block w3-blue">INSERTAR NUEVO EQUIPO</a>
    </div>
   
  </div>
</div>

  <input class="w3-input w3-border w3-padding" type="text" placeholder="Buscar Equipo..." id="myInput" onkeyup="myFunction()">
  <br>

  <table class="w3-table-all" id="myTable">
    <thead>
      <tr class="w3-indigo">
        <th style="width:40%;">Id Equipo</th>
        <th style="width:40%;">Nombre</th>
        <th style="width:40%;">Marca</th>
        <th style="width:40%;">Modelo</th>
        <th style="width:40%;">Descripción</th>
        <th style="width:40%;">Laboratorio de origen</th>
        <th style="width:40%;">Estado</th>
        <th style="width:40%;">Fecha Registro</th>
        <th style="width:40%;">Eliminar</th>
        <th style="width:40%;">Modificar</th>
      </tr>
    </thead>
    <?php
       foreach ($equipos as $datos):
     ?>
    <tr>
      <td><?= $datos['idequipo']; ?></td>
      <td><?= $datos['nombre_equipo']; ?></td>
      <td><?= $datos['marca_equipo']; ?></td>
      <td><?= $datos['modelo_equipo']; ?></td>
      <td><?= $datos['descripcion_equipo']; ?></td>
      <td><?= $datos['laboratorio_idlaboratorio']; ?></td>
      <td><?= $datos['estado_equipo']; ?></td>
      <td><?= $datos['fecha_registro_equipo']; ?></td>  
      <td><a href="<?=base_url('eliminar/'.$datos['idequipo']);?>"><i class="fa-solid fa-trash-can"></i></a></td>
      <td><a href="<?=base_url('editare/'.$datos['idequipo']);?>"><i class="fa-solid fa-pencil"></i></a></td>   
    </tr>
    <?php endforeach; ?>
      
  </table>

  <script>
function myFunction() {
  var input, filter, table, tr, td, i;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[0];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }
  }
}
</script>

</div>

</body>
</html>