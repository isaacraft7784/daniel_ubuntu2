<!DOCTYPE html>
<html lang="en" dir="ltr">
    
    <head>
        <meta charset="UTF-8">
        <title>Solicitar Capacitación</title>
        <link rel="stylesheet" href="style.css">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
    <body>

        <div class="container">
            <div class="title"><center>Capacitaciones</center></div>
            <a href="<?= base_url('pedirCap'); ?>">Regresar</a><br>
            <form action="<?= base_url('nuevaCap')?>" method="post">
                <div class="user-details">
                    
                        <input type="hidden" id="id" name="id" >


                    <div class="input-box">
                        <span class="details">Fecha de inicio de la capacitación</span>
                        <input type="date" value="2023-30-03" min="2023-01-01" max="2023-12-31"   name="fecha_inicio" required>
                    </div>

                    <div class="input-box">
                        <span class="details">Fecha final de la capacitación </span>
                        <input type="date" value="2023-30-03" min="2023-01-01" max="2023-12-31"   name="fecha_fin" required>
                    </div>

                    <div class="input-box">
                        <span class="details">ID de usuario</span>
                        <input type="text" placeholder="Descripción"  name="id_usuario">
                    </div>

                    <div class="input-box">
                        <span class="details">ID de la capacitación</span>
                        <input type="text" value="<?=$capaci['idcapacitacion'];?>" name="id_cap" required>
                    </div> 

                </div>

                <div class="button">
                    <input type="submit" value="Enviar">
                </div>
            </form>
        </div>

<style>

*{
     margin: 0;
     padding: 0;
     box-sizing: border-box;
     font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}

body{
    display: flex;
    height: 100vh;
    justify-content: center;
    align-items: center;
    background: linear-gradient(135deg, #191970, #ffff);
}


.container{
    max-width: 800px;
    width: 90%;
    background: #dbd7d7;
    padding: 25px 30px;
    border-radius: 30px;
}

.container .title{
    font-size: 25px;
    font-weight: 500;
    position: relative;
}

.container .title::before{
    content: ´´;
    position: absolute;
    left: 0;
    bottom: 0;
    height: 3px;
    width: 30px;
    background: linear-gradient(135deg, #191970, #ffff);
}

.container form .user-details{
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
    margin: 20px 0 12px 0;
}

form .user-details .input-box{
    margin-bottom: 15px;
    width: calc(100% / 2 - 20px);
}

.user-details .input-box .details{
    display: block;
    font-weight: 500;
    margin-bottom: 5px;
}

.user-details .input-box input{
    height: 45px;
    width: 100%;
    outline: none;
    border-radius: 5px;
    border: 1px solid #ccc;
    padding-left: 15px;
    font-size: 16px;
}

.user-details .input-box input:focus,
.user-details .input-box input:valid{
    border-color: #9b59b6;
}

form .gender-details .gender-title{
    font-size: 20px;
    font-weight: 500;
}

form .gender-details .category{
    display: flex;
    width: 80%;
    margin: 14px;
    justify-content: space-between;
}

.gender-details .category label{
    display: flex;
    align-items: center;
}
form input[type="radio"]{
    display: none;
}
form .button{
    height: 45px;
    margin: 45px 0;
}

form .button input{
    height: 100%;
    width: 100%;
    outline: none;
    color: #fff;
    border: none;
    font-size: 18px;
    font-weight: 500;
    border-radius: 5px;
    letter-spacing: 1px;
    background: linear-gradient(135deg, #191970, #9b59b6);
}

form .button input:hover{
    background: linear-gradient(-135deg, #71b7e6, #9b59b6);
}


@media (max-width: 584){
    .container{
    max-width: 100%;
}
form .user-details .input-box{
    margin-bottom: 15px;
    width: 100%;
}
form .gender-details .category{
    width: 100%;
}

.container form .user-details{
    max-height: 300px;
    overflow-y: scroll;
}

.user-details::-webkit-scrollbar{
    width: 0px;
}


}

</style>
    </body>
</html>