<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="stylesheet" href=
    "https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.css">
    <title>Document Title</title>
</head>
<body>
<div class="w3-container">
   
  <h2>Usuarios de laboratorios</h2><br>
   <a href="<?= base_url('alta_usuario'); ?>"> Crea un usuario</a><br>
   <h4>Lista de usuarios registrados</h4>
  <table class="w3-table w3-striped w3-bordered">
    <tr>
      <th>ID</th>
      <th>Matrícula</th>
      <th>Nombre</th>
      <th>Apellido paterno</th>
      <th>Apellido materno</th>
      <th>Password</th>
      <th>Correo</th>
      <th>Teléfono</th>
      <th>NSS</th>
      <th>Carrera</th>
      <th>Rol</th>
      <th>Estado de usuario</th>
      <th>Fecha de creación</th>
      <th>Eliminar</th>
      <th>Modificar</th>
    </tr>
     <?php
       foreach ($datitos as $dato):
     ?>
    <tr>
      <td><?= $dato['idusuario']; ?></td>
      <td><?= $dato['matrcula_usuario']; ?></td>
      <td><?= $dato['nombre_usuario']; ?></td>
      <td><?= $dato['apellido_paterno']; ?></td>
      <td><?= $dato['apellido_materno']; ?></td>
      <td><?= $dato['password_usuario']; ?></td>
      <td><?= $dato['correo_usuario']; ?></td>
      <td><?= $dato['telefono_usuario']; ?></td>
      <td><?= $dato['numero_seguro_social']; ?></td>
      <td><?= $dato['carrera_idcarrera']; ?></td>
      <td><?= $dato['rol_usuario']; ?></td> 
      <td><?= $dato['estado_usuario']; ?></td> 
      <td><?= $dato['fecha_creacion_usuario']; ?></td>  
      <td><a href="#"><i class="fa-solid fa-trash-can"></i></a></td>
      <td><a href="#"><i class="fa-solid fa-pencil"></i></a></td>   
    </tr>
    <?php endforeach; ?>
    </table>
</div>

</body>
</body>
</html>