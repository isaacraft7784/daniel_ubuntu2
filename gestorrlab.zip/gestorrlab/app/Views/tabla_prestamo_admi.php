<!DOCTYPE html>
<html>
<title>Equipos Admin</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Bebas Neue">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Nabla">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

    <meta name="viewport" content="width=device-width,initial-scale=1"/>
<body>

    <style>
.w3-allerta {
  font-family: "Bebas Neue", Sans-serif;
}
</style>

<style>
.w3-allert {
  font-family: "Bebas Neue", Sans-serif;
}
</style>

<style>
.w3-nabla {
  font-family: "Heebo", Sans-serif;
}
</style>
<div class="w3-container w3-indigo w3-center w3-allerta">
  <p class="w3-xxxlarge">Prestamos</p>
</div>

<div class="w3-container w3-center w3-nabla">
<h2><p class="w3-allert">Lista de prestamos</p></h2>
  <p>Administrador</p>

  
<div class="w3-top">
  <div class="w3-row w3-padding w3-indigo">
    <div class="w3-col s3">
      <a href="#" class="w3-button w3-block w3-indigo"></a>
    </div>
    <div class="w3-col s3">
      <a href="<?= base_url('caps_admi'); ?>" class="w3-button w3-block w3-blue">CAPACITACIONES</a>
    </div>
    <div class="w3-col s3">
      <a href="<?= base_url('equipos'); ?>" class="w3-button w3-block w3-blue">EQUIPOS</a>
    </div>
    <div class="w3-col s3">
      <a href="<?= base_url('inicio_admin')?>" class="w3-button w3-block w3-blue">inicio</a>
    </div>
  </div>
</div>

  <input class="w3-input w3-border w3-padding" type="text" placeholder="Buscar Prestamos..." id="myInput" onkeyup="myFunction()">
  <br>
<table class="w3-table-all" id="myTable">
    <thead>

      <tr class="w3-indigo">
        <th>Id Prestamo</th>
        <th>Fecha de Prestamo</th>
        <th>Hora de inicio</th>
        <th>Hora Final</th>
        <th>Observaciones</th>
        <th>Equipo id equipo</th>
        <th>Usuario id usuario</th>
        <th>Laboratorio id laboratorio</th>
        <th>Estado</th>
        <th>Fecha Registro</th>
        <th>Aprobado</th>
        <th>NO Aprobado</th>
        <th>Eliminar</th>
    </thead>
    <?php
       foreach ($prest as $dato):
     ?>
    <tr>
      <td><?= $dato['idprestamo']; ?></td>
      <td><?= $dato['prestamo_fecha']; ?></td>
      <td><?= $dato['hora_inicio']; ?></td>
      <td><?= $dato['hora_final']; ?></td>
      <td><?= $dato['prestamo_observaciones']; ?></td>
      <td><?= $dato['equipo_idequipo2']; ?></td>
      <td><?= $dato['usuario_idusuario']; ?></td>
      <td><?= $dato['laboratorio_idlaboratorio3']; ?></td>
      <td><?= $dato['estado_prestamo']; ?></td>
      <td><?= $dato['fecha_registro_prestamo']; ?></td>
      <td><a href="<?=base_url('email/');?>"><i class="glyphicon glyphicon-thumbs-up"></i></a></td>
      <td><a href=<?=base_url('email/');?>><i class="glyphicon glyphicon-remove"></i></a></td>
      <td><a href="<?=base_url('borrarpresta/'.$dato['idprestamo']);?>"><i class="fa-solid fa-trash-can"></i></a></td>
    </tr>
    <?php endforeach; ?>
  </table>

  <script>
function myFunction() {
  var input, filter, table, tr, td, i;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[0];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }
  }
}
</script>

</div>

</body>
</html> 