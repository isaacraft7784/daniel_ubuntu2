<!DOCTYPE html>
<html>
<title>Equipos Admin</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Bebas Neue">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Nabla">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

    <meta name="viewport" content="width=device-width,initial-scale=1"/>
<body>

    <style>
.w3-allerta {
  font-family: "Bebas Neue", Sans-serif;
}
</style>

<style>
.w3-allert {
  font-family: "Bebas Neue", Sans-serif;
}
</style>

<style>
.w3-nabla {
  font-family: "Heebo", Sans-serif;
}
</style>


<div class="w3-container w3-indigo w3-center w3-allerta">
  <p class="w3-xxxlarge">Equipos</p>
</div>

<div class="w3-container w3-center w3-nabla">
<h2><p class="w3-allert">Lista de Equipos</p></h2>
  <p>Usuario</p>
  <center>
  </div>
       <div class="w3-col s3">
      <a href="<?= base_url('inicio')?>" class="w3-button w3-indigo w3-block w3-middle" align="center">inicio</a>

    </div>
    </center>
  <input class="w3-input w3-border w3-padding" type="text" placeholder="Buscar Equipo..." id="myInput" onkeyup="myFunction()">
  <br>

<table class="w3-table-all" id="myTable">
    <thead>



      <tr class="w3-indigo">
        <th>Id Equipo</th>
        <th>Nombre Equipo</th>
        <th>Marca Equipo</th>
        <th>Modelo Equipo</th>
        <th>Descripcion Equipo</th>
        <th>Laboratorio_idLaboratorio</th>
        <th>Estado Equipo</th>
        <th>fecha_registro_equipo</th>
        <th>Solicitar</th>
       
    </thead>
    <?php
       foreach ($equipos as $datos):
     ?>
    <tr>
      <td><?= $datos['idequipo']; ?></td>
      <td><?= $datos['nombre_equipo']; ?></td>
      <td><?= $datos['marca_equipo']; ?></td>
      <td><?= $datos['modelo_equipo']; ?></td>
      <td><?= $datos['descripcion_equipo']; ?></td>
      <td><?= $datos['laboratorio_idlaboratorio']; ?></td>
      <td><?= $datos['estado_equipo']; ?></td>
      <td><?= $datos['fecha_registro_equipo']; ?></td>  
      <td><a href="<?= base_url('prestamo/'.$datos['idequipo'].'/'.$datos['laboratorio_idlaboratorio']);?>"><i class="w3-button w3-round-xxlarge">Solicitar Equipo</i></a></td>
    </tr>  
    <?php endforeach; ?>
  </table>

  <script>
function myFunction() {
  var input, filter, table, tr, td, i;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[0];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }
  }
}
</script>

</div>

</body>
</html> 