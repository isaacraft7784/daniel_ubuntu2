<?php 
namespace App\Models;

use CodeIgniter\Model;

class CapModel extends Model{
    protected $table      = 'capacitacion';
    protected $primaryKey = 'idcapacitacion';
     protected $allowedFields = ['nombre_capacitacion','duracion_capacitacion','descripcion_capacitacion',
    'nombre_instructor','clave_capacitacion','estado_capacitacion','fecha_registro_capacitacion'];

}