<?php 
namespace App\Models;

use CodeIgniter\Model;

class PrestamoModel extends Model{
    protected $table      = 'prestamo';
    protected $primaykey = 'idprestamo';
    protected $allowedFields = ['idprestamo','prestamo_fecha','hora_inicio','hora_final','prestamo_observaciones',
    'equipo_idequipo2','usuario_idusuario','laboratorio_idlaboratorio3','estado_prestamo','fecha_registro_prestamo'];
}