<?php
namespace App\Models;


use CodeIgniter\Model;
class sesion extends Model{

        protected $table      = 'usuario';
        
        protected $allowedFields = ['idusuario','matrcula_usuario','nombre_usuario','apellido_paterno','apellido_materno',
        'password_usuario','correo_usuario'];
        

    
}
?>