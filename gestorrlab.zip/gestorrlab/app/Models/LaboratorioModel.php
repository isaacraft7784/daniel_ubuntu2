<?php 
namespace App\Models;

use CodeIgniter\Model;

class LaboratorioModel extends Model{
    protected $table      = 'laboratorio';
    protected $primaryKey = 'idlaboratorio';
    protected $allowedFields = ['idlaboratorio','nombre_laboratorio','ubicacion_laboratorio','nombre_responsable_laboratorio',
    'nombre_edificio','numero_piso','estado_laboratorio','fecha_registro_laboratorio'];
}