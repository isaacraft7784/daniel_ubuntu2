<?php 
namespace App\Models;

use CodeIgniter\Model;

class UsuarioModel extends Model{
    protected $table      = 'usuario';
    protected $primaryKey = 'idusuario';
    protected $allowedFields = ['matrcula_usuario','nombre_usuario','apellido_paterno','apellido_materno',
    'password_usuario','correo_usuario','telefono_usuario','numero_seguro_social','carrera_idcarrera',
    'rol_usuario','estado_usuario','fecha_creacion_usuario'];  
    }
    ?>