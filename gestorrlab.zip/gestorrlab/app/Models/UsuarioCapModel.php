<?php 
namespace App\Models;

use CodeIgniter\Model;

class UsuarioCapModel extends Model{
    protected $table      = 'usuario_capacitacion';
    protected $primaykey = 'idusuario_capacitacion';
    protected $allowedFields = ['idusuario_capacitacion','fecha_inicio_capacitacion','fecha_fin_capacitacion','usuario_idusuario2',
    'capacitacion_idcapacitacion2'];
}
?>