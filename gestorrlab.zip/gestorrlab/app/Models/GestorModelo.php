<?php
//todas las consultas de la base de datos
namespace App\Models;
use CodeIgniter\Databse\Controller\ConnectionInterface; //Interfaz de la base de atos
use CodeIgniter\Model;//llama a nuestro modelo
class GestorModelo extends Model
{
  function __constructor(){

  }
  public function conscarr()
  $data = $this->db->query("SELECT nombre FROM carrera");
  return $data;
}

?>