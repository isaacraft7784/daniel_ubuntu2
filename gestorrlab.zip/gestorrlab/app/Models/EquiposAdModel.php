<?php 
namespace App\Models;

use CodeIgniter\Model;

class EquiposAdModel extends Model{
    protected $table = 'equipo';
    protected $primaryKey = 'idequipo';
    protected $allowedFields = ['idequipo','nombre_equipo','marca_equipo','modelo_equipo','descripcion_equipo',
    'laboratorio_idlaboratorio','estado_equipo','fecha_registro_equipo'];
}